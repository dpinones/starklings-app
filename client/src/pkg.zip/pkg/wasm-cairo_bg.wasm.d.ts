/* tslint:disable */
/* eslint-disable */
export const memory: WebAssembly.Memory;
export function greet(a: number, b: number, c: number): void;
export function compileCairoProgram(a: number, b: number, c: number, d: number): void;
export function runCairoProgram(a: number, b: number, c: number, d: number, e: number, f: number, g: number, h: number, i: number): void;
export function runTests(a: number, b: number, c: number, d: number, e: number, f: number, g: number, h: number, i: number, j: number, k: number, l: number, m: number): void;
export function compileStarknetContract(a: number, b: number, c: number, d: number, e: number): void;
export function __wbindgen_add_to_stack_pointer(a: number): number;
export function __wbindgen_export_0(a: number, b: number): number;
export function __wbindgen_export_1(a: number, b: number, c: number, d: number): number;
export function __wbindgen_export_2(a: number, b: number, c: number): void;
